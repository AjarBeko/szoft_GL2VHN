using Csillagok.Models;

namespace Csillagok
{
    public partial class Form1 : Form
    {
        hajosContext context = new hajosContext();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var stars = context.StarData.Select(s => new { s.Hip, s.X, s.Y, s.Magnitude }).ToList();
            Graphics g = this.CreateGraphics();
            g.Clear(Color.Black);
            Color c = Color.Gold;
            Pen pen = new Pen(c);
            Brush brush = new SolidBrush(c);
            float cx = ClientRectangle.Width / 2;
            float cy = ClientRectangle.Height / 2;
            var lines = context.ConstellationLines.ToList();


            double nagyitas = 501;
            foreach (var star in stars)
            {
                if (Math.Sqrt(Math.Pow(star.X, 2) + Math.Pow(star.Y, 2)) > 1) continue;
                {
                    float x1 = (float)(nagyitas * star.X);
                    float y1 = (float)(nagyitas * star.Y);

                    double size = 20 * Math.Pow(10, (star.Magnitude) / -2.5);

                    if (size < 2) size = 1;
                    g.FillEllipse(brush, x1 + cx, y1 + cy, (float)size, (float)size);
                }
            }

            foreach (var line in lines)
            {
                var star1 = (from s in stars where s.Hip == line.Star1 select s).FirstOrDefault();
                var star2 = (from s in stars where s.Hip == line.Star2 select s).FirstOrDefault();
                if (star1 == null || star2 == null) continue;
                float x1 = (float)(nagyitas * star1.X);
                float y1 = (float)(nagyitas * star1.Y);
                float x2 = (float)(nagyitas * star2.X);
                float y2 = (float)(nagyitas * star2.Y);
                g.DrawLine(pen, x1 + cx, y1 + cy, x2 + cx, y2 + cy);
            }
        }
    }
}