﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_ZH
{
    internal class Vegpont:PictureBox
    {
        public Vegpont()
        {
            Height = 60;
            Width = 60;
            BackColor = Color.Red;
            
        }
    }
}
