namespace Projekt_ZH
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PictureBox player = new PictureBox();

        List<PictureBox> bricks = new List<PictureBox>();
        int elteltido = new int();
        int lepesszam = new int();
        private void Form1_Load(object sender, EventArgs e)
        {

            player.Location = new Point(0, 0);
            player.Size = new Size(20, 20);
            player.BackColor = Color.RebeccaPurple;
            Controls.Add(player);
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader sr = new StreamReader(ofd.FileName);
                    byte sorokszama = 0;
                    int soroksz�ma = 0;
                    while (!sr.EndOfStream)
                    {
                        string sor = sr.ReadLine();
                        for (int i = 0; i < sor.Length; i++)
                        {
                            if (sor[i] == '#')
                            {
                                PictureBox pb = new PictureBox();
                                pb.Location = new Point(i * 20, soroksz�ma * 20);
                                pb.Size = new Size(20, 20);
                                pb.BackColor = Color.DarkRed;
                                this.Controls.Add(pb);
                                bricks.Add(pb);
                            }

                            
                            if (sor[i] == 's')
                            {
                                KezdoHely kh = new KezdoHely();
                                kh.Top = soroksz�ma * 32;
                                kh.Left = i * 32;
                                Controls.Add(kh);
                            }
                            if (sor[i] == 'c')
                            {
                                Vegpont vp = new Vegpont();
                                vp.Top = soroksz�ma * 32;
                                vp.Left = i * 32;
                                Controls.Add(vp);
                            }
                        }
                        soroksz�ma++;
                    }
                    KeyDown += Form1_KeyDown;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                timer1.Enabled = false;
                if (MessageBox.Show("Biztos vagy benne, hogy elhagyod a g�m�t???", "Pause men�", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Close();
                }
                timer1.Enabled = true;
            }
            int x = player.Location.X;
            int y = player.Location.Y;

            if (e.KeyCode == Keys.Right)
            {
                x += 20;
            }

            if (e.KeyCode == Keys.Left)
            {
                x -= 20;
            }
            if (e.KeyCode == Keys.Up)
            {
                y -= 20;
            }
            if (e.KeyCode == Keys.Down)
            {
                y += 20;
            }
            var wall = bricks.FirstOrDefault(w => w.Location.X == x && w.Location.Y == y);
            if (wall == null)
            {
                player.Location = new Point(x, y);
                lepesszam++;
                lepesszamLabel.Text = "L�p�seid sz�ma: " + lepesszam.ToString();

            }

            foreach (Control vege in Controls)
            {
                if (vege is Vegpont)
                {
                    if (vege.Top == player.Top && vege.Left == player.Left)
                    {
                        MessageBox.Show("K�sz ennyi, Cs�kolom!");
                        Close();
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            elteltido++;
            elteltIdoLabel.Text = "Ennyi ideje nyomod: " + elteltido.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            lepesszam = 0;
            elteltido = 0;
            player.Location = new Point(0, 0);
        }
    }

}