﻿namespace Projekt_ZH
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            elteltIdoLabel = new Label();
            lepesszamLabel = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            SuspendLayout();
            // 
            // elteltIdoLabel
            // 
            elteltIdoLabel.AutoSize = true;
            elteltIdoLabel.Location = new Point(178, 1);
            elteltIdoLabel.Name = "elteltIdoLabel";
            elteltIdoLabel.Size = new Size(115, 15);
            elteltIdoLabel.TabIndex = 0;
            elteltIdoLabel.Text = "Ennyi ideje nyomod:";
            // 
            // lepesszamLabel
            // 
            lepesszamLabel.AutoSize = true;
            lepesszamLabel.Location = new Point(311, 1);
            lepesszamLabel.Name = "lepesszamLabel";
            lepesszamLabel.Size = new Size(92, 15);
            lepesszamLabel.TabIndex = 1;
            lepesszamLabel.Text = "Lépéseid száma:";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(103, 1);
            label1.Name = "label1";
            label1.Size = new Size(69, 15);
            label1.TabIndex = 2;
            label1.Text = "Újrakezdem";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGoldenrodYellow;
            ClientSize = new Size(1292, 898);
            Controls.Add(label1);
            Controls.Add(lepesszamLabel);
            Controls.Add(elteltIdoLabel);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label elteltIdoLabel;
        private Label lepesszamLabel;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
    }
}