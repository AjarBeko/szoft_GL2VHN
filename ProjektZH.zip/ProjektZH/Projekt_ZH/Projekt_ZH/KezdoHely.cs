﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_ZH
{
    internal class KezdoHely:PictureBox
    {
        public KezdoHely()
        {
            Height = 60;
            Width = 60;
            BackColor = Color.Green;
            
        }
    }
}
