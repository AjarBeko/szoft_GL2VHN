﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI.Models;

namespace UI
{
    public partial class UserControl2 : UserControl
    {
        StudiesContext context = new StudiesContext();
        public UserControl2()
        {
            InitializeComponent();
            FillDateSource();
            listBox1.DisplayMember = "Name";
        }

        private void FillDateSource()
        {
            listBox1.DataSource = (from l in context.Courses
                                   where l.Name.Contains(textBox1.Text)
                                   select l).ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillDateSource();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Course course = listBox1.SelectedItem as Course;

            dataGridView1.DataSource = (from k in context.Lessons
                                        where k.CourseFk == course.CourseSk
                                        select new
                                        {
                                            Nap = k.DayFkNavigation.Name,
                                            Sáv = k.TimeFkNavigation.Name,
                                            Oktató = k.InstructorFkNavigation.Name
                                        }).ToList();
        }
    }
}
