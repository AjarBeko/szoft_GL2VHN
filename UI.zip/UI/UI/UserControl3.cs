﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI.Models;

namespace UI
{
    public partial class UserControl3 : UserControl
    {
        StudiesContext context = new StudiesContext();
        public UserControl3()
        {
            InitializeComponent();
            listBox1.DisplayMember = "Name";
            FillDataSource();
        }

        private void FillDataSource()
        {
            listBox1.DataSource = (from h in context.Instructors
                                   where h.Name.Contains(textBox1.Text)
                                   select h).ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillDataSource();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Instructor instructor = (Instructor)listBox1.SelectedItem;
            dataGridView1.DataSource = (from o in context.Instructors
                           where o.InstructorSk == instructor.InstructorSk
                           select new
                           {
                               Státusz = o.StatusFkNavigation.Name,
                               Employment = o.EmployementFkNavigation.Name
                           }).ToList();
        }
    }
}
