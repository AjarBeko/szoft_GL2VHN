﻿using gyak11.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gyak11
{
    public partial class UserControl3 : UserControl
    {
        Models.StudiesContext context = new Models.StudiesContext();
        public UserControl3()
        {
            InitializeComponent();
            Adatbetolt();
            listBox1.DisplayMember = "Name";
        }
        private void Adatbetolt()
        {
            listBox1.DataSource = (from i in context.Instructors
                                   where i.Name.Contains(textBox1.Text)
                                   select i).ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Adatbetolt();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Instructor instructor = (Instructor)listBox1.SelectedItem;
            var lessons = from l in context.Instructors
                          where l.InstructorSk == instructor.InstructorSk
                          select new
                          {
                              Státusz = l.StatusFkNavigation.Name,
                              Employment = l.EmployementFkNavigation.Name
                          };
            dataGridView1.DataSource = lessons.ToList();
        }
    }
}
